# Таблетки — сборка APK

## Что нужно поставить (один раз)
1. Node.js 20 или новее — https://nodejs.org
2. Android Studio — https://developer.android.com/studio
   (при первом запуске согласись скачать Android SDK)

## Сборка
Открой терминал в папке проекта и выполни по очереди:

    npm install
    npx cap add android
    npx cap sync
    npx cap open android

Откроется Android Studio. Подожди, пока внизу закончится «Gradle sync»
(первый раз может быть 5–10 минут). Потом:

    Build → Build Bundle(s) / APK(s) → Build APK(s)

Готовый файл:

    android/app/build/outputs/apk/debug/app-debug.apk

Скинь его на телефон (Telegram, USB, облако), открой и разреши
установку из неизвестных источников.

## Первый запуск на телефоне
- Разреши уведомления.
- Если телефон откроет экран «Будильники и напоминания», включи для приложения.

## Если уведомления не приходят
Это почти всегда настройки энергосбережения:
- Настройки → Приложения → Таблетки → Батарея → «Без ограничений»
- На Xiaomi/Redmi/POCO ещё включи «Автозапуск»
- На Samsung: убери приложение из «Спящих приложений»

Если Android Studio ругается на отсутствие разрешений, добавь в
android/app/src/main/AndroidManifest.xml перед <application>:

    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>

и снова Build APK.

## Как менять приложение
Весь интерфейс в www/index.html. После правок: npx cap sync и новый Build APK.
